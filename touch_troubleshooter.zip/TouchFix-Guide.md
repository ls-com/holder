# TouchFix — Operator Guide

Touchscreen repair and update automation for HP / Lenovo / Dell notebooks.

---

## Quick start

| Situation | Command |
|---|---|
| Unit arrived, want to know what's wrong | `.\TouchFix.ps1` |
| Suspect driver stack (most common) | `.\TouchFix.ps1 -Mode Repair` |
| Bench refurb, do everything | `.\TouchFix.ps1 -Mode Full -AutoReboot` |
| Everything including BIOS | `.\TouchFix.ps1 -Mode Full -IncludeBios -AutoReboot` |
| Confirm fix after reboot | `.\TouchFix.ps1` |

Run from an elevated PowerShell prompt. The script self-elevates if you forget.

```
powershell -ExecutionPolicy Bypass -File .\TouchFix.ps1 -Mode Full
```

---

## What each stage does

**Stage 1 — Diagnose (always runs, read-only)**
Queries the Win32 digitizer API, enumerates HID touch devices and I2C/Serial IO
controllers, checks their problem codes, and flags generic-Microsoft drivers
sitting where an OEM driver should be.

**Stage 2 — Repair driver stack**
Starts `hidserv` and `TabletInputService` if stopped, enables any disabled touch
device, then `pnputil /remove-device` on the HID touch device followed by
`pnputil /scan-devices`. This is the fix your customer performed manually.

**Stage 3 — Vendor drivers and firmware**

| Vendor | Primary engine | Fallback |
|---|---|---|
| Dell | `dcu-cli.exe /scan` then `/applyUpdates` | none — DCU must be installed |
| HP | HP Image Assistant `/Operation:Analyze /Action:Install` | HPCMSL module |
| Lenovo | LSUClient module (`Get-LSUpdate`) | Thin Installer `/CM -search A` |

**Stage 4 — Windows Update**
Microsoft.Update COM API: search, accept EULAs, download, install.

**Stage 5 — BIOS** (only with `-IncludeBios`)
Compares installed version against the vendor catalog and flashes if newer.

---

## Design decisions worth knowing

**Repair runs before updates.** Your customer's fix was a driver reinstall.
Running a 20-minute BIOS flash first to reach the same outcome wastes bench time
and adds risk. The script also **stops as soon as touch works** — pass
`-RunAllStages` to override.

**BIOS is off by default.** Enabling it is a deliberate choice, not a default.
See the warning below.

**Removes the HID touch device, not the I2C controller.** On several HP and
Lenovo models the touchpad and internal keyboard also hang off the I2C bus.
Removing a healthy controller can leave a bench tech with no input device until
the rescan completes. The controller is only included when it is *itself* in an
error state, and the script warns first.

**Creates a restore point** before any change, and clears the 24-hour throttle
that normally blocks a second one.

**Does not force feature updates.** The COM API doesn't install 23H2 → 24H2
anyway, and silently upgrading a customer's Windows build is a support incident
waiting to happen. The script flags it instead.

---

## Warnings

**BIOS flashing on customer machines.** The script gates this on AC power and
≥30% battery, but a flash interrupted by a power loss can brick the board. On a
customer-owned machine you are absorbing that liability. Recommended: use
`-IncludeBios` on bench units only, and have customers run without it.

**Lenovo ThinkCentre and ThinkStation need a full shutdown**, not a restart, to
apply BIOS. The script reads `HKLM\SOFTWARE\LSUClient\BIOSUpdate\ActionNeeded`
and reports which is required — read that line before hitting restart.

**Dell BIOS passwords.** If your units ship with a BIOS password set, `dcu-cli`
needs `-encryptedPassword` and `-encryptionKey`. Add them to the stage 3 call.

**Vendor tools must already be installed** for Dell and HP. The script reports
the download URL if missing rather than pulling executables from the internet
unattended. Lenovo is the exception — LSUClient comes from PSGallery, which the
script will install.

---

## Deployment

**Bench use:** drop both files on the tech's desktop.

**Customer self-service:** ship `-Mode Repair` only. It's the highest-yield,
lowest-risk stage and needs no vendor tooling. Wrap it in a `.cmd` like the
earlier diagnostic so it's a double-click.

**Fleet use:** the script is idempotent and returns a report file per run. Ship
it via your RMM, collect `TouchFix_Report_*.txt`, and grep for the final verdict
line to auto-triage RMAs.

---

## Reading the output

The last section is the decision point:

- `*** TOUCHSCREEN IS WORKING ***` → close the ticket, no RMA
- `*** REBOOT REQUIRED ***` → restart, re-run in Diagnose mode
- `*** TOUCHSCREEN STILL NOT WORKING ***` → software exhausted, approve the RMA

That third line is the one that saves you money. It means drivers were
reinstalled, vendor updates applied, and Windows is current — so the fault is
the digitizer panel or its ribbon cable, and no further phone support will help.

---

## Untested

This was written without access to a Windows machine. Test on a known-good unit
and a known-broken unit before it touches a customer's laptop. The stages most
likely to need adjustment are the vendor CLI paths (stage 3) and the exit-code
handling, which varies by tool version.
